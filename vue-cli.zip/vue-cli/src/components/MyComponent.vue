<template>
  <div class="border">
    <h1>새로운 컴포넌트</h1>
    <MyComponentItem
      static-props="WOW!!!"
      :dynamic-props="dynamicProps"
      @child-to-parent="parentGetEvent"
      @child-input = "getDynamicData"
    />
  </div>
</template>

<script>
import MyComponentItem from '@/components/MyComponentItem'
export default {
  name: 'MyComponent',
  data: function() {
    return {
      dynamicProps: 'DP'
    }
  },
  components: {
    MyComponentItem,
  },
  methods: {
    parentGetEvent: function() {
      console.log('BUG!')
    },
    getDynamicData: function(childInputData) {
      console.log(`사용자가 입력한 값 : ${childInputData}`)
    }
  }
}
</script>

<style>
  .border {
    border: solid 1px black;
  }
</style>