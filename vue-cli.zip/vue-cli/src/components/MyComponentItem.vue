<template>
  <div class="border2">
    <h2>새로운 컴포넌트22</h2>
    <h3>{{ staticProps }}</h3>
    <h3>{{ dynamicProps }}</h3>
    <button @click="childToParent ">click</button>
    <input
      type="text"
      v-model="childInputData"
      @keyup.enter="childInput"
    >
  </div>
</template>

<script>
export default {
  name: "MyComponentItem",
  data: function() {
    return{
      childInputData: null,
    }
  },
  props: {
    staticProps: String,
    dynamicProps: String,
  },
  methods: {
     childToParent: function() {
      this.$emit('child-to-parent')
     },
     childInput: function () {
      this.$emit('child-input', this.childInputData)
      this.childInputData = null;
     }
  }
}
</script>

<style>
  .border2 {
    border: solid 1px violet;
  }
</style>